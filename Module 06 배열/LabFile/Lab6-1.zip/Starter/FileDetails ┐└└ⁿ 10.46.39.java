import java.io.*;

public class FileDetails {
    public static void main(String[] args) {
        //
        // To-do: Add code here
        //

        // read the file that passed from parameter of main method
        // File file = new File(fileName);
        // try (FileInputStream stream = new FileInputStream(file)) {
        //     
        // To-do Add code here
        //
        // }
        // catch (Exception e) {
        //     e.printStackTrace();
        // }
    }
}