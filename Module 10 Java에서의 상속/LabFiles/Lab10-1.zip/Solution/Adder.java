class Adder implements BinaryOp {
    public int apply(int left, int right) {
        return left + right;
    }
}