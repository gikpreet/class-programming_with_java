interface BinaryOp {
    int apply(int left, int right);
}
