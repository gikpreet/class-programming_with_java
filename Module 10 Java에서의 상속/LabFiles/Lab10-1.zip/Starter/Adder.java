class Adder {
    public int apply(int left, int right) {
        return left + right;
    }
}