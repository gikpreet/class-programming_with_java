interface BinaryOp {

}
