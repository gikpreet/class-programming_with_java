public class ArrayListInvaliedAddException extends RuntimeException {
    public ArrayListInvaliedAddException(String message) {
        super(message);
    }
}
