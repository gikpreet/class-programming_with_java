public class LinkedListInvaliedOperationException extends RuntimeException {
    public LinkedListInvaliedOperationException(String message) {
        super(message);
    }
}
