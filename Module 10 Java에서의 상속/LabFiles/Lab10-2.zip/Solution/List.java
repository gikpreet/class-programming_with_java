public interface List {
    void add(int data);
    int remove(int index);
    int get(int index);
}