public class ArrayList implements List {
    private int[] elements;
    private int index = 0;

    public ArrayList() {
        this.elements = new int[50];
    }

    //
    // add code here for implements add method of List interface
    //

    //
    // add code here for implements remove method of List interface
    //

    //
    // add code here for implements get method of List interface
    //

    //
    // add code here for implements size method of List interface
    //
}
