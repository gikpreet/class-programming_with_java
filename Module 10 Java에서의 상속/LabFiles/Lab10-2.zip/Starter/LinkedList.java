public class LinkedList /* To-do: implement List interface */ {
    Node head;
    int size;

    //
    // To-do: Add Constructor here
    //

    //
    // To-do Add overloaded constructor here
    //

    //
    // To-do: add add method here
    //

    //
    // To-do: add get method here
    //

    //
    // To-do: add remove method here
    //

    // 
    // To-do: add size method here
    //

    public boolean isEmpty() {
        return this.head == null ? true : false;
    }
}