public class Node {
    Object data;
    Node nextNode;

    public Node(Object data) {
        this.data = data;
    }
}
