public class ArrayListInvalidOperationException extends RuntimeException {
    public ArrayListInvalidOperationException(String message) {
        super(message);
    }
}
