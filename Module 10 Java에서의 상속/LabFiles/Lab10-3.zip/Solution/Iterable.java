public interface Iterable {
    Iterator iterator();
}