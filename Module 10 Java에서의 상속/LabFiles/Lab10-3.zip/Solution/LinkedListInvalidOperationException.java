public class LinkedListInvalidOperationException extends RuntimeException {
    public LinkedListInvalidOperationException(String message) {
        super(message);
    }
}
