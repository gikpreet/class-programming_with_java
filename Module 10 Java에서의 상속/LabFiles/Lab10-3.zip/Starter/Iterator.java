public interface Iterator {
    boolean hasnext();
    int next();
}