public interface Enumerable {
    public Enumerator getEnumerator();
}
