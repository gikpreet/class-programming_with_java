public interface Enumerator {
    public boolean hasNext();
    public Object next();
}
