public interface List extends Enumerable {
    void add(Object item);
    Object get(int index);
    int size();
    boolean isEmpty();
}