public class Test {
    public static void main(String[] args) {
        List list = new ArrayList();
        list.add(1);
        list.add("James");
        list.add("Celine");

        //System.out.println(list.get(0));
        //System.out.println(list.get(1));
    }
}
