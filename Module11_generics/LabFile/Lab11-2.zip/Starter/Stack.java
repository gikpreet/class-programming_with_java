public class Stack {
    private int[] elements;
    public int index = 0;

    public Stack(int size) {
        this.elements = new int[size];
    }

    public void push(int item) {
        if (this.index < this.elements.length) {
            this.elements[index++] = item;
        }
        else {
            throw new IllegalStateException("Stack Full");
        }
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        else {
            return this.elements[--this.index];
        }
    }

    public boolean isEmpty() {
        return this.index == 0 ? true : false;
    }
}

class StackTest {
    public static void main(String[] args) {
        Stack stack = new Stack(5);
        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
    }
}