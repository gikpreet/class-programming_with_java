public class Man extends Person {
    Man(String name) {
        super(name);
    }

    @Override
    public String getGender() {
        return "Man";
    }
}
