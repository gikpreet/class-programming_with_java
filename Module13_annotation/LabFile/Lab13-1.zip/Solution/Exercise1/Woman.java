public class Woman extends Person {
    Woman(String name) {
        super(name);
    }

    public String getGender() {
        return "Woman";
    }
}
