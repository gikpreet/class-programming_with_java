public class Man extends Person {
    Man(String name) {
        super(name);
    }

    public String getGeder() {
        return "Man";
    }
}
