class Adder {
    public int apply(int right, int left) {
        return right + left;
    }
}