public class Multiplier {
    public int apply(int left, int right) {
        return left * right;
    }
}