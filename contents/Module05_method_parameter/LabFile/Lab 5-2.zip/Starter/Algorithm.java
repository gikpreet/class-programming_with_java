public class Algorithm {
    //
    // To-do add sigma method here
    //

    //
    // To-do add pi method here
    //

    //
    // To-do add accumulate method here
    //

    //
    // To-do add overloaded accumulate method here
    //

    public static void main(String[] args) {
        //
        // To-do: Add code here
        //   
    }
}