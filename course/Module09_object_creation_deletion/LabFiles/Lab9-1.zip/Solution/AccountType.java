enum AccountType {
    Checking,
    Deposit,
    Saving
}
