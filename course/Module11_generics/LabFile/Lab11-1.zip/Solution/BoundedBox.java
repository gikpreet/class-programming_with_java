public class BoundedBox<T extends Number> {
    String name;
    T value;

    BoundedBox(String name) {
        this.name = name;
    }

    public String getName() {
        return  this.name;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return  this.value;
    }
}

class BoundedBoxTest {
    public static void main(String[] args) {
        BoundedBox<Integer> box1 = new BoundedBox<Integer>("box1");
        BoundedBox<Double> box2 = new BoundedBox<Double>("box2");

        box1.setValue(1);
        box2.setValue(2.0d);

        int valueFromBox1 = box1.getValue().intValue();
        int valueFromBox2 = box2.getValue().intValue();

        System.out.println("Box1 has " + valueFromBox1);
        System.out.println("Box2 has " + valueFromBox2);
    }
}