public class Box<T> {
    private String name;
    private T value;

    public Box(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return this.value;
    }
}

class BoxTest {
    public static void main(String[] args) {
        Box<String> box = new Box<>("Celine");
        box.setValue("a bag");

        String result = box.getValue();
        System.out.printf("%s has %s", box.getName(), result);
    }
}