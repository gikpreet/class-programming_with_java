public class MultpeTypeBox<T,U> {
    U name;
    T value;

    public MultpeTypeBox(U name) {
        this.name = name;
    }

    public U getName() {
        return this.name;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return  this.value;
    }
}

class MultpeTypeBoxTest {
    public static void main(String[] args) {
        MultpeTypeBox<Integer, String> box1 = new MultpeTypeBox<>("Celine");

        box1.setValue(1);
        System.out.println(box1.getName() + " has " + box1.getValue());
    }
}
