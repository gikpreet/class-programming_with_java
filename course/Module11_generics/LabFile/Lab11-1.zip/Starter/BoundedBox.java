public class BoundedBox<T> {
    String name;
    T value;

    BoundedBox(String name) {
        this.name = name;
    }

    public String getName() {
        return  this.name;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return  this.value;
    }
}

class BoundedBoxTest {
    public static void main(String[] args) {
        BoundedBox<Integer> box1 = new BoundedBox<Integer>("box1");
        BoundedBox<String> box2 = new BoundedBox<String>("box2");

        box1.setValue(1);
        box2.setValue("celine");

        System.out.println("Box1 has " + box1.getValue());
        System.out.println("Box2 has " + box2.getValue());
    }
}
