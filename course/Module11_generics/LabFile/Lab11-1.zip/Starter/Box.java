public class Box {
    private String name;
    private int value;

    public Box(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
}

class BoxTest {
    public static void main(String[] args) {
        Box box = new Box("Celine");
        box.setValue(1);

        int result = (int)box.getValue();
        System.out.printf("%s has %s", box.getName(), result);
    }
}