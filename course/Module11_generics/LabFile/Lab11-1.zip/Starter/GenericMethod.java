public class GenericMethod {
    public static void bubbleSort(Integer[] items) {
        for(int i = items.length - 1; i > 0; i--) {
            for(int j = 0 ; j < i ; j++) {
                if (items[j] > items[j + 1]) {
                    Integer item = items[j];
                    items[j] = items[j + 1];
                    items[j + 1] = item;
                }
            }
        }
    }
}

class GenericMethodTest {
    public static void main(String[] args) {
        Integer[] integerList =  {1, 10, 7, 2, 5, 4, 9, 8, 3, 6};
        String[] stringList =  {"Celine", "Jason", "Robert", "Adrian", "William"};

        GenericMethod.bubbleSort(integerList);

        for(int i: integerList) {
            System.out.print(i + " ");
        }
    }
}