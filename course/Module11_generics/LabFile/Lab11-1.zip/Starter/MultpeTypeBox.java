public class MultpeTypeBox<T> {
    String name;
    T value;

    public MultpeTypeBox(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public T getValue() {
        return  this.value;
    }
}

class MultpeTypeBoxTest {
    public static void main(String[] args) {
        MultpeTypeBox<Integer> box1 = new MultpeTypeBox<>("box1");

        box1.setValue(1);
        System.out.println(box1.getName() + " has " + box1.getValue());
    }
}
