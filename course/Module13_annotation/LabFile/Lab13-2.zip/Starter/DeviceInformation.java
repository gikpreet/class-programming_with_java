import java.lang.annotation.*;

//
// To-do: add Annotations here
//
public @interface DeviceInformation {
    //
    // To-do: add fields here
    //
}